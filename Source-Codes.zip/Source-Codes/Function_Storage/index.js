//gcloud functions deploy readCSVinStorage --runtime nodejs8 --trigger-resource grocerydelivery-bucket --trigger-event google.storage.object.finalize
//gcloud functions logs read --limit 50

'use strict';
const {google} = require("googleapis");
const {Storage} = require("@google-cloud/storage")
const request = require('request');


exports.readCSVinStorage = async(data, context, callback) => {
  var file = data;
  var DL_data = [];

  if (!file.name.endsWith(".csv")) {
    console.log("Not a .csv file, ignoring.");
    return;
  } else if (file.resourceState === 'not_exists') {
    console.log(`File ${file.name} deleted.`);
  } else if (file.metageneration === '1') {
    // metageneration attribute is updated on metadata changes.
    // on create value is 1
    console.log(`File ${file.name} uploaded.`);
    console.log(`  Event: ${context.eventId}`);
    console.log(`  Event Type: ${context.eventType}`);
    console.log(`  Bucket: ${file.bucket}`);
    console.log(`  File: ${file.name}`);
    console.log(`  Metageneration: ${file.metageneration}`);
    console.log(`  Created: ${file.timeCreated}`);
    console.log(`  Updated: ${file.updated}`);

    const storage = new Storage();
    let fileContents = new Buffer('');

    storage.bucket(file.bucket).file(file.name).createReadStream()
    .on('error', function(err) {
      reject('The Storage API returned an error: ' + err);
    })
    .on('data', function(chunk) {
      fileContents = Buffer.concat([fileContents, chunk]);
    })
    .on('end', function() {
      let content = fileContents.toString('utf8');
      console.log("CSV content read as string : " + content );
      DL_data = content.split(",");
        console.log(`  Order Number: ${DL_data[1]}`);
        console.log(`  DL ID: ${DL_data[2]}`);
        console.log(`  DL Name: ${DL_data[3]}`);
        console.log(`  DL Mobile: ${DL_data[4]}`);
        console.log(`  Origine: ${DL_data[5]}`);
        console.log(`  Destination: ${DL_data[6]}`);
        console.log(`  Delivery Date: ${DL_data[7]}`);
        console.log(`  Delivery Time: ${DL_data[8]}`);
      //resolve(content);

        sleep(500).then(() => {
            triggerDistance(DL_data[5],DL_data[6],DL_data[1],DL_data[2],DL_data[3],DL_data[4],DL_data[7],DL_data[8]);
        })
                    
        resolve(content);
    });

  } else {
    console.log(`File ${file.name} metadata updated.`);
  }

  callback();
};


function encodeData(data) {
    return Object.keys(data).map(function(key) {
        return [key, data[key]].map(encodeURIComponent).join("=");
    }).join("&");
}


function triggerDistance(origin_in,destination_in,id,Del_No,Name,Tel,Data,Time){
    var url = "https://us-central1-cloud-function-test-274101.cloudfunctions.net/driveDistance?"
    var para_data = {origin_in: origin_in, destination_in, destination_in, id: id, Del_No: Del_No, Name: Name, Tel: Tel, Data: Data, Time: Time}
    var final_url = url + encodeData(para_data); //example - 'https://us-central1-cloud-function-test-274101.cloudfunctions.net/driveDistance?origin_in=11%20Winthrop%20Crt%20Keysborough%20VIC%203173&destination_in=11%20Red%20Brush%20Drive%20Keysborough%20VIC%203173'
    console.log(final_url);

    request(final_url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(body);
            var str = body;
            //var obj = JSON.parse(str);
            //console.log(`Distance at triggerDist : ${obj.Distance_km} km.`);
            //console.log(`Duration at triggerDist : ${obj.Duration_min} min.`);
                
                //let data = JSON.stringify(body, null, 2);
                
            //var dis = obj.Distance_km;
            //var dur = obj.Duration_min;
                
            //var trim_data = {
            //        "Distance_KM" : dis,
            //        "Duration_MIN" : dur
            //};
                
            //return trim_data;
            console.log(`before send.`);
            //return body;
            res.status(200).send(body);
            
            //res.status(200).send(dis.toString(),dur.toString());
            
        }
        console.log(`outside if.`);
    });

console.log(`outside if.`);

    
}

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}