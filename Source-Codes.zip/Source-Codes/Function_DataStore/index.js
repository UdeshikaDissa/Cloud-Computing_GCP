//gcloud functions deploy FUNCTION_NAME --runtime nodejs8 --trigger-http --allow-unauthenticated
//gcloud functions deploy Function_DataStore --runtime nodejs8 --trigger-http --allow-unauthenticated
//https://us-central1-cloud-function-test-274101.cloudfunctions.net/Function_DataStore?id=%27K123345%27&name=%27Chuuwaa%27&password=345234
const request = require('request');

const Datastore = require('@google-cloud/datastore');
const datastore = new Datastore({
	projectId: 'cloud-function-test-274101',
	keyFilename: 'cloud-function-test-274101-8baca1153b75.json'
});
const kindName = 'Delivery_data';

exports.Function_DataStore = (req, res) => {
    let Action = req.query.Action || req.body.Action || 'New';
    let id = req.query.id || req.body.id || 'G8888';
	let Del_No = req.query.Del_No || req.body.Del_No || 'D9999';
	let Name = req.query.Name || req.body.Name || 'XXXX Name';
    let Tel = req.query.Tel || req.body.Tel || '430456702';
    let pickup = req.query.pickup || req.body.pickup || '11 Winthrop Crt Keysborough';
    let Dropoff = req.query.Dropoff || req.body.Dropoff || '11 Winthrop Crt Keysborough';
    let Data = req.query.Data || req.body.Data || '31/12/2021';
    let Time = req.query.Time || req.body.Time || '15:30';
    let Distance = req.query.Distance || req.body.Distance || 0.0;
    let Duration = req.query.Duration || req.body.Duration || 0.0;
    let Fee = req.query.Fee || req.body.Fee || 0.0;

if (Action === 'New'){
	datastore
		.save({
			key: datastore.key([kindName,id]),
			data: {
				Del_No: Del_No,
                Name: Name,
                Tel: Tel,
                pickup: pickup,
                Dropoff: Dropoff,
                Data: Data,
                Time: Time,
                Distance: Distance,
                Duration: Duration,
                Fee: Fee
            }
		})
		.catch(err => {
		    console.error('ERROR:', err);
		    res.status(200).send(err);
		    return;
		});

            sleep(500).then(() => {
                whatsappMessage(Name,Tel,id,Data,Time,pickup,Dropoff,Distance,Fee);
            })

	res.status(200).send(Name);
}

else if (Action === 'Append'){
    Fee = 5 + Distance*.5;
    datastore
		.update({
			key: datastore.key([kindName,id]),
			data: {
				Distance: Distance,
                Duration: Duration,
                Fee: Fee
            }
		})
		.catch(err => {
		    console.error('ERROR:', err);
		    res.status(200).send(err);
		    return;
		});

    res.status(200).send(id);
}
};

function encodeData(data) {
    return Object.keys(data).map(function(key) {
        return [key, data[key]].map(encodeURIComponent).join("=");
    }).join("&");
}

function whatsappMessage(driver,message_to,delivery_order,delivery_date,delivery_time,pick_up,drop_off,distance,fee){
    var url = "https://us-central1-cloud-function-test-274101.cloudfunctions.net/sendWhatsapp?"
    var para_data = {driver: driver, message_to: message_to, delivery_order: delivery_order, delivery_date: delivery_date, delivery_time: delivery_time, pick_up: pick_up, drop_off: drop_off, distance: distance,fee: fee}
    var final_url = url + encodeData(para_data); //example - 'https://us-central1-cloud-function-test-274101.cloudfunctions.net/driveDistance?origin_in=11%20Winthrop%20Crt%20Keysborough%20VIC%203173&destination_in=11%20Red%20Brush%20Drive%20Keysborough%20VIC%203173'
    console.log(final_url);

    request(final_url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(body);
            var str = body;
                            
            //return trim_data;
            console.log(`before send.`);
            //return body;
            res.status(200).send(body);
            
            //res.status(200).send(dis.toString(),dur.toString());
            
        }
        console.log(`outside if.`);
    });

console.log(`outside if.`);
    
}

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}