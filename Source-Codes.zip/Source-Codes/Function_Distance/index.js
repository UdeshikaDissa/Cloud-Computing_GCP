/**
 *gcloud functions deploy driveDistance --runtime nodejs8 --trigger-http --allow-unauthenticated
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

const request = require('request');
var API_KEY = 'AIzaSyAFReYoWRgmSqog_09Tu8yk0gi7ACMHmCE';

exports.driveDistance = (req, res) => {
  //let message = req.query.message || req.body.message || 'Hello to driveDistance Function!';
    let origin_in = req.query.origin_in || req.body.origin_in || '11 Winthrop Crt Keysborough VIC 3173';
	let destination_in = req.query.destination_in || req.body.destination_in || '11 Winthrop Crt Keysborough VIC 3173';
    let id = req.query.id || req.body.id || 'G9999';
	let Del_No = req.query.Del_No || req.body.Del_No || 'D9999';
	let Name = req.query.Name || req.body.Name || 'XXXX Name';
    let Tel = req.query.Tel || req.body.Tel || '61444444444';
    let Data = req.query.Data || req.body.Data || '31/12/2021';
    let Time = req.query.Time || req.body.Time || '15:30';
  
    var url = "https://maps.googleapis.com/maps/api/distancematrix/json?"
    var para_data = {units: "metric", origins: origin_in, destinations: destination_in, key: API_KEY}

    var final_url = url + encodeData(para_data); //example - https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=11+Winthrop+Court,KEysbouroug&destinations=236+Alisma+Boulevard,Cranbourne+North&key=AIzaSyAFReYoWRgmSqog_09Tu8yk0gi7ACMHmCE'
    console.log(final_url);

    
    request(final_url, function (error, response, body) { 
  //request('https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=11+Winthrop+Court,KEysbouroug&destinations=236+Alisma+Boulevard,Cranbourne+North&key=AIzaSyAFReYoWRgmSqog_09Tu8yk0gi7ACMHmCE', function (error, response, body) {
      if (!error && response.statusCode == 200) {
            console.log(body);
            var str = body;
            var obj = JSON.parse(str);
            console.log(`Distance : ${obj.rows[0].elements[0].distance.value} meters.`);
            console.log(`Duration : ${obj.rows[0].elements[0].duration.value} sec.`);
            
            //let data = JSON.stringify(body, null, 2);
            
            var dis = obj.rows[0].elements[0].distance.value/1000;
            var dur = obj.rows[0].elements[0].duration.value/60;
            
            var trim_data = {
                "Distance_km" : dis,
                "Duration_min" : dur
            };
            
            Fee = 5 + dis*0.5;

            sleep(500).then(() => {
                saveDataStore(Del_No,id,Name,Tel,origin_in,destination_in,Data,Time,dis,dur,Fee);
            })
            

            res.status(200).send(trim_data);
            //res.status(200).send(dis.toString(),dur.toString());
            
      }
});  

    message = "new End";
  //res.status(200).send(message);
};

function encodeData(data) {
    return Object.keys(data).map(function(key) {
        return [key, data[key]].map(encodeURIComponent).join("=");
    }).join("&");
}

function saveDataStore(Del_No,id,Name,Tel,origin_in,destination_in,Data,Time,dis,dur,Fee){
    var url = "https://us-central1-cloud-function-test-274101.cloudfunctions.net/Function_DataStore?"
    var para_data = {Del_No: Del_No, id: id, Name: Name, Tel: Tel, pickup: origin_in, Dropoff: destination_in, Data: Data, Time: Time, Distance: dis, Duration: dur, Fee: Fee}
    var final_url = url + encodeData(para_data); //example - 'https://us-central1-cloud-function-test-274101.cloudfunctions.net/driveDistance?origin_in=11%20Winthrop%20Crt%20Keysborough%20VIC%203173&destination_in=11%20Red%20Brush%20Drive%20Keysborough%20VIC%203173'
    console.log(final_url);

    request(final_url, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            console.log(body);
            var str = body;
                            
            //return trim_data;
            console.log(`before send.`);
            //return body;
            res.status(200).send(body);
            
            //res.status(200).send(dis.toString(),dur.toString());
            
        }
        console.log(`outside if.`);
    });

console.log(`outside if.`);
    
}

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}