//gcloud functions deploy sendWhatsapp --runtime nodejs8 --trigger-http --allow-unauthenticated
'use strict';

//const twilio = require('twilio');

const accountSid = 'ACcfdafe3c737fba12300d5593c076c9f0';
const authToken = 'd169aeb11080c2dd4042103f47d4e191';

exports.sendWhatsapp = (req, res) => {

    let driver = req.query.driver || req.body.driver || 'Santhush';
	let message_to = req.query.message_to || req.body.message_to || '430456702';
    let delivery_order = req.query.delivery_order || req.body.delivery_order || 'D1009';
    let delivery_date = req.query.delivery_date || req.body.delivery_date || '29/06/2020';
    let delivery_time = req.query.delivery_time || req.body.delivery_time || '06:30PM';
    let pick_up = req.query.pick_up || req.body.pick_up || '11 Winthrop Crt, Keysborough VIC 3173';
    let drop_off = req.query.drop_off || req.body.drop_off || '22 Holbrook Cr, Brunswick West VIC 3055';
    let distance = req.query.distance || req.body.distance || '10';
    let fee = req.query.fee || req.body.fee || '15';

const client = require('twilio')(accountSid, authToken);

client.messages.create({
  from: 'whatsapp:+14155238886',
  body: 'Hi Delivery Driver '+ driver + '. You have a delivery order ' 
  + delivery_order + ' on ' +delivery_date+ ' at ' +delivery_time+ '. Pick-up at ' + pick_up + '. Drop-off at ' 
  + drop_off + '. Delivery Distance ' 
  + distance + 'km. Delivery Fee $' + fee + '. Call Grocery Delivery on 400946591 to confirm the delivery order.',
  to: 'whatsapp:+61'+ message_to
})//.then(message => console.log(message.sid));
 .then(function (message) {
            console.log(message.sid + '\n');
            console.log('Message Sent to :+' + message_to)
        })

res.status(200).send("Sent");

}