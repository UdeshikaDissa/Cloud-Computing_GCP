<?php

	include_once("nav.html");
if(isset($_SESSION['login_admin'])){
   header("location: landing.php"); // Redirecting To Profile Page
}
?>

<html lang="en">

	<body>

		<form id ="login" method="post" action="admin_login_script.php">
		

			<div >
				<p>Admin login..</p>
			</div><br><br><br><br><br>
		
			<div class="login-form">
				
				<input name="adminid" type="adminid" class="form-control" placeholder="Your Admin ID" required>
				<br>
				<input name="adminpassword" type="password" class="form-control" placeholder="Your Password" required><br>
				
					
				<button type="submit" class="login">Login</button>
				<label>
				
				<input type="checkbox" checked="checked" name="remember"> Remember me
				</label>
			</div>
		
		
			
			<div class="login-form" >
				<button type="button" class="cancelbtn">Cancel</button>
				<span class="psw">Forgot <a href="#">password?</a></span>
			
			</div>
				
				
		</form><br><br><br><br><br><br>
	

	</body>
</html>

<?php

	include_once("footer.html");

?>