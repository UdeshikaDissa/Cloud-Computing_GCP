<?php

include_once("nav.html");

?>

<!DOCTYPE html>

<html lang="en">
	<body>
	
	<h1> Our Pricing </h1><br>
	
	<p style="color:#ff5722;text-align:middle;padding: 60px" >
	Contact us to get pricing information.
	</p>
	
		<br><br><br><br><br><br><br><br><br><br><br><br>

	</body>

</html>


<?php

	include_once("footer.html");

?>