<?php

	include_once("nav.html");

?>

<html lang="en">

	<body>
	
		<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSe6oKQLt1nXmXUhNYmzwbcDPyLO20F_wapk7R8wyS_taA1uaQ/viewform?embedded=true" width="600" height="600" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>

	</body>
</html>

<?php

	include_once("footer.html");

?>