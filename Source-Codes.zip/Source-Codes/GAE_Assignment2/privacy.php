<?php

include_once("nav.html");

?>

<!DOCTYPE html>

<html lang="en">
	<body>
	
	<h1> Privacy Policy </h1><br>
	
	<p style="color:#ff5722;text-align:left;padding: 60px" >
	The personal information We collect from you is what is reasonably necessary for our business functions.<br><br>
	Your account is protected by a password for your privacy and security. We will take all reasonable steps to protect the information We hold about you from unauthorised access, use and disclosure.
	</p>
	
		<br><br><br><br><br><br><br><br><br><br><br><br>

	</body>

</html>


<?php

	include_once("footer.html");

?>