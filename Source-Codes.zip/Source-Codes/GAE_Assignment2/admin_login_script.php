<?php
session_start(); // Starting Session
$error = ''; // Variable To Store Error Message

'use strict';
require 'vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;

//if (isset($_POST['submit'])) 
//{
    
// Define $username and $password
$admin_id = $_POST['adminid'];
$admin_pass_word = $_POST['adminpassword'];

$datastore = new DatastoreClient([
    'projectId' => 'cloud-function-test-274101'
]);

// Create an entity
//$key = $datastore->key('DP_users', 'D1002');
//$new_user = $datastore->entity($key);

//$new_user['name'] = 'Mahinda Rajapakshe2';
//$new_user['password'] = 'dsferw2';
//$datastore->insert($new_user);

$key = $datastore->key('Admin_users', $admin_id);
$entity = $datastore->lookup($key);

if (empty($entity['name'])) 
{
   $error = "User ID is invalid";
} 
else 
{
    if ($entity['password']==$admin_pass_word)
    {
        $_SESSION['login_admin'] = $entity['name']; // Initializing Session
        $_SESSION['admin_login_password'] = $entity['password']; // Initializing Session
        $_SESSION['adminid'] = $user_id;
        header("location: admin.php"); // Redirecting To Profile Page
    } 
    else
    {
        $error = "Password is invalid";
        
    }
}
//}
include_once("Alogin.php");
?>