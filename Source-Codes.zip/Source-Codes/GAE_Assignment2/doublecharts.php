<?php
session_start(); 


?>



<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Load Charts and the corechart and barchart packages.
      google.charts.load('current', {'packages':['corechart']});

      // Draw the pie chart and bar chart when Charts is loaded.
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = new google.visualization.arrayToDataTable([
		['DP ID', 'Earning ($)',{ role: 'style' }],
          ['D1001',<?php echo $_SESSION['DP1_Total_Fee_Array'][0] ?>, '#003f5c'],
          ['D1002',<?php echo $_SESSION['DP1_Total_Fee_Array'][1] ?>, '#ff6361'],
          ['D1003',<?php echo $_SESSION['DP1_Total_Fee_Array'][1] ?>, '#ffa600'],
          
        ]);
		
        var data2 = new google.visualization.arrayToDataTable([
		['Desc', 'Amount',{ role: 'style' }],
          ['Total Distance (km)', <?php echo array_sum($_SESSION['DP1_Total_Distance_Array']) ?>, '#58508d'],
          ['Total Fee ($)',<?php echo array_sum($_SESSION['DP1_Total_Fee_Array']) ?>, '#ffa600'],
        ]);

        var piechart_options = {title:'Total Earning of each Delivery Partner',
                       width:400,
                       height:300,
					   colors: ['#003f5c','#ff6361', '#ffa600' ]};
        var piechart = new google.visualization.PieChart(document.getElementById('piechart_div'));
        piechart.draw(data, piechart_options);

        var barchart_options = {title:'Total trip Distance and Total fee',
                       width:500,
                       height:300,
                       legend: 'none',
					   bar: {groupWidth: "60%"}};
					   
					   		// Add annotation to columns
		var barchart_view = new google.visualization.DataView(data2);
		barchart_view.setColumns([0, 1,
								{ calc: "stringify",
								  sourceColumn: 1,
								  type: "string",
                                  role: "annotation" },
								2]);
        var barchart = new google.visualization.ColumnChart(document.getElementById('barchart_div'));
        barchart.draw(barchart_view, barchart_options);
      }
</script>
<body>
    <!--Table and divs that hold the pie charts-->
    <table class="columns">
      <tr>
        <td><div id="piechart_div" style="border: 1px solid #ccc"></div></td>
        <td><div id="barchart_div" style="border: 1px solid #ccc"></div></td>
      </tr>
    </table>
  </body>
</html>
