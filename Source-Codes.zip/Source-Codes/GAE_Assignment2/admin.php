<?php

	session_start(); // Starting Session
    include_once("navUser.html");
    $error = ''; // Variable To Store Error Message
    
    'use strict';
require 'vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;

?>

<html lang="en">

	<body>
	
	<h1 style="color:#ff5722" > Welcome Admin </h1><br>


		<div class="row">
			<div class="side">
				<h2>NEW ORDERS</h2>
				<h5>Upload a new order:</h5>
				
				<div class="fakeimg" style="height:200px;">
		
			<!-- File Upload -->
					<p>Click on the "Upload File" button to upload .csv Order file:</p>
		
					<button class="upload" onclick=" window.open('https://console.cloud.google.com/storage/browser/grocerydelivery-bucket', '_blank'); return false;">Upload New Order (.csv)</button>
				
				</div>
	
				


				
				<!-- Delivery Info  -->
				
				<h2>DELIVERY ORDERS</h2>
				<h5>Select an order to view details:</h5>
				
				<div class="fakeimg" style="height:200px;">
		
					<form action="" method="post">
						<label>Order ID:</label> <input type="text" name="Order_id" placeholder="Enter Order ID (starts with G)" required> 
						<input type="submit" value="Load" name="submit"> <br><br>
					</form>
				
				</div>
				
<?php
 
if (isset($_POST['Order_id'])){
    $user_id = $_POST['Order_id'];
}else{
    $user_id = "G1001";
}

$datastore = new DatastoreClient([
    'projectId' => 'cloud-function-test-274101'
]);

$key = $datastore->key('Delivery_data', $user_id);
$entity = $datastore->lookup($key);

if (empty($entity['Name'])) 
{
   $error = "Order ID is invalid";
} 

    $DP_ID = '';
    $Distance_currentJob = 0;
	$Dropoff_currentJob = '';
	$Pickup_currentJob = '';
	$Duration_currentJob = 0;
	$Fee_currentJob = 0;
	$Date_currentJob = '';
	$Time_currentJob = '';
        
if (isset($entity['Del_No']))
{
    $status = "Valid Order....";
    $DP_ID = $entity['Del_No'];
    $Distance_currentJob = $entity['Distance'];
    $Dropoff_currentJob = $entity['Dropoff'];
    $Pickup_currentJob = $entity['pickup'];
    $Duration_currentJob = $entity['Duration'];
    $Fee_currentJob = $entity['Fee'];
    $Date_currentJob = $entity['Data'];
    $Time_currentJob = $entity['Time'];

}
else
{
    $status = "Invalid Order";
        
}

$DP_List = array("D1001", "D1002", "D1003", "D1004");
$DP_Fee_Final = array();
$DP_Distance_Final = array();
$DP_Count = sizeof($DP_List);

for ($x = 0; $x < $DP_Count; $x++){

    sleep(0.25);

    $query1 = $datastore->query()
        ->kind('Delivery_data')
        ->filter('Del_No', '=', $DP_List[$x])
        ->order('Distance', Query::ORDER_DESCENDING);

    $Distance_DP = array();
    $Fee_DP = array();
    $result_DP = null;
    $result_DP = $datastore->runQuery($query1);

    foreach ($result_DP as $task) {
        $Distance_DP[] = $task['Distance'];
        $Fee_DP[] = $task['Fee'];
    }
    
$DP_Fee_Final[$x] = array_sum($Fee_DP);
$DP_Distance_Final[$x] = array_sum($Distance_DP);

}

$_SESSION['DP1_Total_Fee_Array'] = $DP_Fee_Final;
$_SESSION['DP1_Total_Distance_Array'] = $DP_Distance_Final;

?>

				<h3>Order Details</h3>
				
                <div class="side1">
                    <label><b>DP ID: </b></label> <span><?php echo $DP_ID ?></span><br><br>
					<label><b>Current Order ID: </b></label> <span><?php echo $user_id ?></span><br><br>
					<label><b>Status: </b></label> <span><?php echo $status ?></span><br><br>
					<label><b>Pick Up: </b></label> <span><?php echo $Pickup_currentJob ?></span><br><br>
					<label><b>Drop Off: </b></label> <span><?php echo $Dropoff_currentJob ?></span><br><br>
					<label><b>Distance (km): </b></label> <span><?php echo $Distance_currentJob ?></span><br><br>
					<label><b>Duration (min): </b></label> <span><?php echo $Duration_currentJob ?></span><br><br>
					<label><b>Fee ($): </b></label> <span><?php echo $Fee_currentJob ?></span><br><br>
					<label><b>Date: </b></label> <span><?php echo $Date_currentJob ?></span><br><br>
					<label><b>Time: </b></label> <span><?php echo $Time_currentJob ?></span><br><br>
				
				</div>
				
				<!-- End of Delivery Info  -->
				

			</div>
	
			<div class="main">
				<h2>Admin Dashboard</h2>
			
					<div class="piechart"style=";"
					
						<?php
						include_once("doublecharts.php");
						?>	
						
					</div>
				
				<!--<p>Some text..</p>-->
				<!--<p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>-->
				<br>
				<h2>DELIVERY PARTNERS LIST</h2>
				
				<div class="map" style="height:200px;">
				<?php
						include_once("table.html");
				?>
				
				</div>
				



		
			</div>
		</div>			

	</body>
	
</html>

<?php

	include_once("footer.html");

?>