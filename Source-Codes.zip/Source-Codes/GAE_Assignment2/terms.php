<?php

include_once("nav.html");

?>

<!DOCTYPE html>

<html lang="en">
	<body>
	<h1> Terms & Conditions </h1><br>
	
	
	<p style="color:#ff5722;text-align:left;padding: 60px" >
	We deliver groceries very seriously.<br><br>
	If you have an issue, we want to fix it. So please don’t ever hesitate to call us if you need to.<br><br>
	By using this site, you agree and accept our terms and conditions of use. If you do not agree with our terms and conditions of use, you may not use this. </p>
		
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
		
		

	</body>

</html>


<?php

	include_once("footer.html");

?>