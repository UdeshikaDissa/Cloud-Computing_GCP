<?php


switch (@parse_url($_SERVER['REQUEST_URI'])['path']) {
    case '/':
        require 'landing.php';
        break;
    case '/landing.php':
        require 'landing.php';
        break;
    case '/Dlogin.php':
        require 'Dlogin.php';
        break;
    case '/contactUs.php':
        require 'contactUs.php';
        break;
    case '/Alogin.php':
        require 'Alogin.php';
        break;
    case '/about.php':
        require 'about.php';
        break;
    case '/admin.php':
        require 'admin.php';
        break;
    case '/dp_login_script.php':
        require 'dp_login_script.php';
        break;
    case '/admin_login_script.php':
        require 'admin_login_script.php';
        break;
    case '/dp.php':
        require 'dp.php';
        break;
    case '/dataStore_query.php':
        require 'dataStore_query.php';
        break;
    case '/upload_toStorage_index.php':
        require 'upload_toStorage_index.php';
        break;
    case '/pricing.php':
        require 'pricing.php';
        break;
    case '/terms.php':
        require 'terms.php';
        break;
    case '/privacy.php':
        require 'privacy.php';
        break;
    default:
        http_response_code(404);
        exit('Not Found');
}