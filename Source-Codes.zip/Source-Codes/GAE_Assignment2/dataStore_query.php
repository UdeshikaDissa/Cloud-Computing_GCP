<?php
session_start(); // Starting Session
$error = ''; // Variable To Store Error Message

'use strict';
require 'vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;


?>

<!DOCTYPE html>
<html>
<head>
<title>Testing DataStore Query</title>
</head>
<body>

<form action="" method="post">
                <label>Order ID:</label> <input type="text" name="Order_id" placeholder="Enter Order ID (starts with G)" required> <br><br>
                <label>DP Number:</label> <input type="text" name="Del_No" placeholder="Enter DP ID (starts with D)" required> <br><br>
                <input type="submit" value="Get From Data Store" name="submit"> <br><br>
</form>

<?php
//$user_id = "G1234";
$user_id = $_POST['Order_id'];

$datastore = new DatastoreClient([
    'projectId' => 'cloud-function-test-274101'
]);

$key = $datastore->key('Delivery_data', $user_id);
$entity = $datastore->lookup($key);

if (empty($entity['Name'])) 
{
   $error = "Order ID is invalid";
} 

$Del_No = $_POST['Del_No'];

$query = $datastore->query()
        ->kind('Delivery_data')
        ->filter('Del_No', '=', $Del_No)
        ->order('Distance', Query::ORDER_DESCENDING);
        
     
$Distance = array();
$Fee = array();
$result = $datastore->runQuery($query);

foreach ($result as $task) {
        $Distance[] = $task['Distance'];
        $Fee[] = $task['Fee'];
}


    $Distance_currentJob = 0;
    $Dropoff_currentJob = '';
    $Pickup_currentJob = '';
    $Duration_currentJob = 0;
    $Fee_currentJob = 0;
    $Date_currentJob = '';
    $Time_currentJob = '';

 if ($entity['Del_No']==$Del_No)
{
    $status = "Valid Order....";
    $Distance_currentJob = $entity['Distance'];
    $Dropoff_currentJob = $entity['Dropoff'];
    $Pickup_currentJob = $entity['pickup'];
    $Duration_currentJob = $entity['Duration'];
    $Fee_currentJob = $entity['Fee'];
    $Date_currentJob = $entity['Data'];
    $Time_currentJob = $entity['Time'];

}
else
{
    $status = "This is not your job";
        
}

       $destination = $Dropoff_currentJob;
       $api = file_get_contents("https://maps.googleapis.com/maps/api/geocode/json?address=".urlencode($destination)."&key=AIzaSyDnJYCSGG_u7IaU_MbsgeVyMowQzsqOBxQ");
       //$api = file_get_contents("https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=11+Winthrop+Court,KEysbouroug&destinations=236+Alisma+Boulevard,Cranbourne+North&key=AIzaSyAFReYoWRgmSqog_09Tu8yk0gi7ACMHmCE");
       $data = json_decode($api);
       $Lat = $data->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
       $Lon = $data->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
      

$DP_List = array("D1001", "D1002", "D1003", "D1004");
$DP_Fee_Final = array();
$DP_Distance_Final = array();
$DP_Count = sizeof($DP_List);

for ($x = 0; $x < $DP_Count; $x++){

    sleep(0.25);

    $query1 = $datastore->query()
        ->kind('Delivery_data')
        ->filter('Del_No', '=', $DP_List[$x])
        ->order('Distance', Query::ORDER_DESCENDING);

    $Distance_DP = array();
    $Fee_DP = array();
    $result_DP = null;
    $result_DP = $datastore->runQuery($query1);

    foreach ($result_DP as $task) {
        $Distance_DP[] = $task['Distance'];
        $Fee_DP[] = $task['Fee'];
    }
    
$DP_Fee_Final[$x] = array_sum($Fee_DP);
$DP_Distance_Final[$x] = array_sum($Distance_DP);

}

?>

<label><b>Current DP ID: </b></label> <span><?php echo $Del_No ?></span><br><br>
<label><b>Current DP Name: </b></label> <span><?php echo $entity['Name'] ?></span><br><br>
<label><b>Current Order ID: </b></label> <span><?php echo $user_id ?></span><br><br>
<label><b>Status: </b></label> <span><?php echo $status ?></span><br><br>
<label><b>Pick Up: </b></label> <span><?php echo $Pickup_currentJob ?></span><br><br>
<label><b>Drop Off: </b></label> <span><?php echo $Dropoff_currentJob ?></span><br><br>
<label><b>Distance: </b></label> <span><?php echo $Distance_currentJob ?></span><br><br>
<label><b>Duration: </b></label> <span><?php echo $Duration_currentJob ?></span><br><br>
<label><b>Fee: </b></label> <span><?php echo $Fee_currentJob ?></span><br><br>
<label><b>Date: </b></label> <span><?php echo $Date_currentJob ?></span><br><br>
<label><b>Time: </b></label> <span><?php echo $Time_currentJob ?></span><br><br>
<br><br>
<label><b>DP Total Number of Orders: </b></label> <span><?php echo sizeof($Distance) ?></span><br><br>
<label><b>DP Total Distance: </b></label> <span><?php echo array_sum($Distance) ?></span><br><br>
<label><b>DP Total Fee: </b></label> <span><?php echo array_sum($Fee) ?></span><br><br>
<br><br>

<label><b>Lat: </b></label> <span><?php echo ($Lat) ?></span><br><br>
<label><b>Lon: </b></label> <span><?php echo ($Lon) ?></span><br><br>
<br><br>
<br><br>
<label><b>DP 1 </b></label> <span><?php echo $DP_List[0] ?></span><label><b>Total Fee: </b></label> <span><?php echo $DP_Fee_Final[0] ?></span><label><b>Total Distance: </b></label> <span><?php echo $DP_Distance_Final[0] ?></span><br><br>
<label><b>DP 2 </b></label> <span><?php echo $DP_List[1] ?></span><label><b>Total Fee: </b></label> <span><?php echo $DP_Fee_Final[1] ?></span><label><b>Total Distance: </b></label> <span><?php echo $DP_Distance_Final[1] ?></span><br><br>
<label><b>DP 3 </b></label> <span><?php echo $DP_List[2] ?></span><label><b>Total Fee: </b></label> <span><?php echo $DP_Fee_Final[2] ?></span><label><b>Total Distance: </b></label> <span><?php echo $DP_Distance_Final[2] ?></span><br><br>
<label><b>DP 4 </b></label> <span><?php echo $DP_List[3] ?></span><label><b>Total Fee: </b></label> <span><?php echo $DP_Fee_Final[3] ?></span><label><b>Total Distance: </b></label> <span><?php echo $DP_Distance_Final[3] ?></span><br><br>

</body>
</html>