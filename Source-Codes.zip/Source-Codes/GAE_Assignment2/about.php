<?php

include_once("nav.html");

?>

<!DOCTYPE html>

<html lang="en">
	<body>
	
	<h1> About Us </h1><br>
	
	<p style="color:#ff5722;text-align:left;padding: 60px" >
	We manage online delivery orders from the order creation to home delivery. Fast and reliable order management through Google Cloud Platform Services and other third-party
    cloud services. Twilio service are used to manage WhatsApp messaging service to notify the Delivery Partners on newly created orders. Can manange mulpiple Delivery Partners and Admins.
    Provides interactive Dashbord for Delivery Partners and Admins to see Total Earninigs, and Distance Travel. Also drop-off location is shown for selected Order on interactive
    map. </p>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

	</body>

</html>


<?php

	include_once("footer.html");

?>