<?php
    session_start(); // Starting Session
    include_once("navUser.html");
    $error = ''; // Variable To Store Error Message
    
    'use strict';
require 'vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;

?>

<html lang="en">

	<body>
	
	<h1 style="color:#ff5722" >Welcome Delivery Partner: <?php echo $_SESSION['userid'] ?> </h1> <br>


		<div class="row">
			<div class="side">
				<h2>Delivery Orders</h2>
				<h5>Select an order to view details:</h5>
				
				<div class="fakeimg" style="height:200px;">
		
			<!-- Delivery Info  -->

					
					<form action="" method="post">
						<label>Order ID:</label> <input type="text" name="Order_id" placeholder="Enter Order ID (starts with G)" required> 
                        <input type="submit" value="Load" name="submit">
					</form>
				
				</div>
	
<?php
                
if (isset($_POST['Order_id'])){
    $user_id = $_POST['Order_id'];
}else{
    $user_id = "G1001";
}

$datastore = new DatastoreClient([
    'projectId' => 'cloud-function-test-274101'
]);

$key = $datastore->key('Delivery_data', $user_id);
$entity = $datastore->lookup($key);

if (empty($entity['Name'])) 
{
   $error = "Order ID is invalid";
} 

$Del_No = $_SESSION['userid'];
#$Del_No = $_POST['Del_No'];

$query = $datastore->query()
        ->kind('Delivery_data')
        ->filter('Del_No', '=', $Del_No)
        ->order('Distance', Query::ORDER_DESCENDING);
        
     
$Distance = array();
$Fee = array();
$Duration = array();
$result = $datastore->runQuery($query);

foreach ($result as $task) {
        $Distance[] = $task['Distance'];
        $Fee[] = $task['Fee'];
        $Duration[] = $task['Duration'];
}

	$Distance_currentJob = 0;
	$Dropoff_currentJob = '';
	$Pickup_currentJob = '';
	$Duration_currentJob = 0;
	$Fee_currentJob = 0;
	$Date_currentJob = '';
	$Time_currentJob = '';
	                    
if ($entity['Del_No'] == $Del_No)
{
    $status = "Valid Order....";
    $Distance_currentJob = $entity['Distance'];
    $Dropoff_currentJob = $entity['Dropoff'];
    $Pickup_currentJob = $entity['pickup'];
    $Duration_currentJob = $entity['Duration'];
    $Fee_currentJob = $entity['Fee'];
    $Date_currentJob = $entity['Data'];
    $Time_currentJob = $entity['Time'];

}
else
{
    $status = "This is not your job";
        
}

$_SESSION['total_distance'] = array_sum($Distance);
$_SESSION['total_fee'] = array_sum($Fee);
$_SESSION['total_duration'] = array_sum($Duration);
$_SESSION['destination'] = $entity['Dropoff'];

?>

				<h3>Order Details</h3>
				
				<div class="side1">
                    <label><b>DP ID: </b></label> <span><?php echo $Del_No ?></span><br><br>
                    <label><b>Current Order ID: </b></label> <span><?php echo $user_id ?></span><br><br>
					<label><b>Status: </b></label> <span><?php echo $status ?></span><br><br>
					<label><b>Pick Up: </b></label> <span><?php echo $Pickup_currentJob ?></span><br><br>
					<label><b>Drop Off: </b></label> <span><?php echo $Dropoff_currentJob ?></span><br><br>
					<label><b>Distance (km): </b></label> <span><?php echo $Distance_currentJob ?></span><br><br>
					<label><b>Duration (min): </b></label> <span><?php echo $Duration_currentJob ?></span><br><br>
					<label><b>Fee ($): </b></label> <span><?php echo $Fee_currentJob ?></span><br><br>
					<label><b>Date: </b></label> <span><?php echo $Date_currentJob ?></span><br><br>
					<label><b>Time: </b></label> <span><?php echo $Time_currentJob ?></span><br><br>
				
				</div>
			</div>
	
			<div class="main">
				<h2>Dashboard</h2>
				
					<div class="piechart"style=";"
					
						<?php
						include_once("doublecharts_DP.php");
						?>	
						
					</div>
				
				<!--<p>Some text..</p>-->
				<!--<p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>-->
				<br>
				<h2>Drop Off Location</h2>
				
				<div class="map" style="height:200px;">
				<?php
						include_once("gmap.php");
				?>
				
				</div>
				
				<p>Some text..</p> <br><br><br><br><br><br><br><br><br><br><br><br><br>
		
			</div>
		</div>			

	</body>
	
</html>

<?php

	include_once("footer.html");

?>