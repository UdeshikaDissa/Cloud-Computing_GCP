<?php
    //include('dp_login_script.php');
	include_once("nav.html");
if(isset($_SESSION['login_user'])){
   header("location: landing.php"); // Redirecting To Profile Page
}
?>

<html lang="en">

	<body>

		<form id ="login" method="post" action="dp_login_script.php">
		

			<div >
				<p>DP login..</p>
			</div><br><br><br><br><br>
		
			<div class="login-form">
				
				<input name="userid" type="userid" class="form-control" placeholder="Your User ID" required>
				<br>
				<input name="password" type="password" class="form-control" placeholder="Your Password" required><br>
				
					
				<button type="submit" class="login">Login</button>
				<label>
				
				<input type="checkbox" checked="checked" name="remember"> Remember me
                </label>
                <span><?php echo $error; ?></span>
			</div>
		
		
			
			<div class="login-form" >
				<button type="button" class="cancelbtn">Cancel</button>
				<span class="psw">Forgot <a href="#">password?</a></span>
			
			</div>
				
				
		</form><br><br><br><br><br><br>
	

	</body>
</html>

<?php

	include_once("footer.html");

?>